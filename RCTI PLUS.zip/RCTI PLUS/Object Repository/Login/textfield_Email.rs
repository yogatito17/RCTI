<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>textfield_Email</name>
   <tag></tag>
   <elementGuidId>93f46d21-7742-4c17-9d0c-8c96cd92844b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//input [@id='username']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

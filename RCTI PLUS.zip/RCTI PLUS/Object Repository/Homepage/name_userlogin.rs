<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>name_userlogin</name>
   <tag></tag>
   <elementGuidId>2d2d6814-0907-4024-ba11-4ce10dc74043</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span [@class='name']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

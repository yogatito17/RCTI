<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_CantFindContents</name>
   <tag></tag>
   <elementGuidId>dc9a69df-1f3e-49d7-be75-32ff7a3186f1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section [@id='cant-find']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
